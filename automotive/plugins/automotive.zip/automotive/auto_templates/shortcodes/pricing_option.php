<?php
/*
	Automotive Pricing Option Shortcode Template File
	To overwrite this file copy it to automotive-child/auto_templates/shortcodes/pricing_option.php

	Version: 14.1
	Help: https://support.themesuite.com/kb/faq.php?id=9
 */

echo "<li>";
echo do_shortcode( $content );
echo "</li>";