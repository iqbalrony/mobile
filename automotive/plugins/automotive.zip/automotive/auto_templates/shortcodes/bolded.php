<?php
/*
	Automotive Bolded Shortcode Template File
	To overwrite this file copy it to automotive-child/auto_templates/shortcodes/bolded.php

	Version: 14.1
	Help: https://support.themesuite.com/kb/faq.php?id=9
 */

echo "<span style='font-weight: 800;'>" . $content . "</span>";