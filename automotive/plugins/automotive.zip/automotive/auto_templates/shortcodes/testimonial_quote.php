<?php
/*
	Automotive Testimonial Quote Shortcode Template File
	To overwrite this file copy it to automotive-child/auto_templates/shortcodes/testimonial_quote.php

	Version: 14.1
	Help: https://support.themesuite.com/kb/faq.php?id=9
 */

echo testimonial_slider_quote( $name, $content );