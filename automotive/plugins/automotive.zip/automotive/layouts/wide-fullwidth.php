<?php get_header(); ?>
	
	<?php listing_template("wide_fullwidth"); ?>

<?php get_footer(); ?>