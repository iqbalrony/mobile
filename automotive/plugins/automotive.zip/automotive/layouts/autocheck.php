<?php

Automotive_Plugin()->autocheck_get_report();