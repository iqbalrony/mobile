<?php get_header(); ?>
	
    <?php listing_template("boxed_right"); ?>

<?php get_footer(); ?>