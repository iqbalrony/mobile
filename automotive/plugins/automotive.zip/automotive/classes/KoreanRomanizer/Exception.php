<?php
namespace KoreanRomanizer;

/**
 * @see http://ralphschindler.com/2010/09/15/exception-best-practices-in-php-5-3
 */
interface Exception
{
}
