<?php
namespace KoreanRomanizer;

class InvalidArgumentException extends \InvalidArgumentException implements Exception
{
}
